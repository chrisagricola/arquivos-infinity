base = float(input('Digite o valor da base de um retângulo em centímetros: '))
altura = float(input('Digite o valor de sua altura em centímetros: '))

area = base * altura

print(f'O valor da área deste retângulo é de: {area}cm²')